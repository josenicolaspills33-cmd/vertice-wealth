# Vértice Wealth

Painel financeiro de demonstração com o Claude integrado. O site é estático (GitHub Pages) e o assistente fala com a API da Anthropic por um Worker da Cloudflare que guarda a chave. **Nunca coloque a chave da API no `index.html`**, porque ela ficaria pública.

## 1. Subir no GitHub

```bash
cd vertice-wealth
git init && git add . && git commit -m "Vértice Wealth"
git branch -M main
git remote add origin https://github.com/SEU-USUARIO/vertice-wealth.git
git push -u origin main
```

No repositório: **Settings → Pages → Deploy from a branch → main / (root)**. O site fica em `https://SEU-USUARIO.github.io/vertice-wealth/`.

## 2. Publicar o Worker (a ponte com o Claude)

1. Crie uma chave em https://console.anthropic.com e defina um limite de gasto mensal lá.
2. Em `worker/wrangler.toml`, troque `SEU-USUARIO` pelo seu usuário do GitHub.
3. Rode:
```bash
npm i -g wrangler
cd worker
wrangler login
wrangler secret put ANTHROPIC_API_KEY   # cole a chave
wrangler deploy
```
4. Copie o endereço que o deploy mostrar (`https://vertice-wealth-ai.XXXX.workers.dev`) e cole na constante `API_URL` no começo do script do assistente em `index.html`. Depois:
```bash
git add . && git commit -m "Conecta o assistente" && git push
```

## 3. Cuidados

- O Worker só aceita chamadas vindas das origens listadas em `ALLOWED_ORIGIN`, mas qualquer pessoa que abrir seu site consegue conversar usando a sua chave. Mantenha o limite de gasto na Anthropic e, se o site ficar público, crie uma regra de rate limiting na Cloudflare.
- A busca na web precisa estar habilitada na sua organização no Console da Anthropic. Se não estiver, remova a linha `web_search` de `TOOLS` em `worker/worker.js`.
- Para testar localmente: `python3 -m http.server 8000` na pasta do projeto e abra `http://localhost:8000`.
