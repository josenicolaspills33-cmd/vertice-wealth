const TOOLS = [
  { name: "abrir_aba", description: "Abre uma aba do painel para o usuário.",
    input_schema: { type: "object", properties: { aba: { type: "string", enum: ["geral", "investimentos", "historico", "gastos"] } }, required: ["aba"] } },
  { name: "registrar_gasto", description: "Registra um novo gasto em dólares na aba Gastos.",
    input_schema: { type: "object", properties: {
      descricao: { type: "string" }, valor_usd: { type: "number" },
      categoria: { type: "string", enum: ["Moradia", "Alimentação", "Viagens", "Transporte", "Assinaturas", "Outros"] } },
      required: ["descricao", "valor_usd", "categoria"] } },
  { type: "web_search_20250305", name: "web_search", max_uses: 4 },
];

const system = () => `Você é o Claude, criado pela Anthropic, integrado ao painel financeiro "Vértice Wealth". Hoje é ${new Date().toLocaleDateString("pt-BR")}.
Responda qualquer assunto que o usuário trouxer (finanças, programação, escrita, estudos, ciência, dia a dia, ideias), com o mesmo raciocínio, profundidade e honestidade de uma conversa normal com o Claude, em português do Brasil, a menos que ele peça outro idioma. Pense no problema antes de responder, seja direto, admita incerteza e não enrole. Use a busca na web quando a pergunta depender de informação atual.
Quando a pergunta envolver o painel, use os dados fornecidos abaixo. Eles são fictícios e as cotações são simuladas; avise quando isso importar. Em decisões de investimento, explique cenários, riscos e o que você consideraria, sem dar ordens, e lembre que não é consultor financeiro habilitado. Use as ferramentas para abrir abas ou registrar gastos quando o usuário pedir.
Formato: parágrafos curtos; listas só quando ajudam; **negrito** com moderação; blocos de código para código.`;

const json = (obj, status, headers) =>
  new Response(JSON.stringify(obj), { status, headers: { ...headers, "Content-Type": "application/json" } });

export default {
  async fetch(req, env) {
    const allowed = (env.ALLOWED_ORIGIN || "").split(",").map(s => s.trim()).filter(Boolean);
    const origin = req.headers.get("Origin") || "";
    const ok = allowed.includes(origin);
    const cors = {
      "Access-Control-Allow-Origin": ok ? origin : (allowed[0] || ""),
      "Access-Control-Allow-Methods": "POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type",
      "Vary": "Origin",
    };
    if (req.method === "OPTIONS") return new Response(null, { status: 204, headers: cors });
    if (req.method !== "POST" || !ok) return json({ error: "Origem não permitida." }, 403, cors);

    const raw = await req.text();
    if (raw.length > 120000) return json({ error: "Mensagem grande demais." }, 413, cors);
    let body;
    try { body = JSON.parse(raw); } catch { return json({ error: "JSON inválido." }, 400, cors); }
    const { messages, snapshot } = body;
    if (!Array.isArray(messages) || !messages.length || messages.length > 60)
      return json({ error: "Conversa inválida." }, 400, cors);

    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "x-api-key": env.ANTHROPIC_API_KEY, "anthropic-version": "2023-06-01", "content-type": "application/json" },
      body: JSON.stringify({
        model: env.MODEL || "claude-sonnet-5-5",
        max_tokens: 2500,
        system: system() + "\n\nDados atuais do painel: " + String(snapshot || "").slice(0, 8000),
        tools: TOOLS,
        messages,
      }),
    });
    const data = await r.json().catch(() => ({}));
    if (!r.ok) return json({ error: data?.error?.message || "Erro ao falar com a API." }, 502, cors);
    return json(data, 200, cors);
  },
};
